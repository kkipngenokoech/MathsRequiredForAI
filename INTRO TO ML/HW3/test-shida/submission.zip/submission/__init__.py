"""Treat solution as a module so we can import it from the autograder."""

from .npnn import *
